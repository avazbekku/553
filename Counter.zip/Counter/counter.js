let counter = 0

const value = document.querySelector('#value')
const buttons = document.querySelectorAll('.buttons')

buttons.forEach(button =>{
    button.addEventListener('click', function(e){
        const classN = e.target.classList
        if(classN.contains ('decrease')) {
            counter--;
            value.innerHTML = counter
            function red (){
                    document.querySelector('#value').style.color = 'red';
            }
            
            red()
            // console.log(counter);
        }else if(classN.contains ('reset')) {
            counter=0;
            value.innerHTML = counter
            function black (){
                    document.querySelector('#value').style.color = 'black';
            }
    
            black()
            // console.log(counter);
        }else{
            counter++;
            value.textContent = counter
            function green (){
                    document.querySelector('#value').style.color = 'green';
            }
    
            green()
        }
        
        
        
        
        
    })
})

